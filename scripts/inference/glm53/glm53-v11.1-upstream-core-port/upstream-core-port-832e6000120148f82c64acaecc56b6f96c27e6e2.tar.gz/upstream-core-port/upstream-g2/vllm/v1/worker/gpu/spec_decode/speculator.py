# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import Any, Literal

import numpy as np
import torch
import torch.nn as nn

from vllm.config import VllmConfig, get_layers_from_vllm_config
from vllm.config.compilation import CUDAGraphMode
from vllm.distributed.eplb.eplb_state import EplbState
from vllm.logger import init_logger
from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
from vllm.model_executor.models import supports_multimodal_embeddings
from vllm.multimodal import MULTIMODAL_REGISTRY
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu.attn_utils import (
    build_attn_metadata,
    init_attn_backend,
)
from vllm.v1.worker.gpu.block_table import BlockTables
from vllm.v1.worker.gpu.cp_utils import prepare_dcp_local_seq_lens
from vllm.v1.worker.gpu.input_batch import InputBatch, InputBuffers
from vllm.v1.worker.gpu.model_states.interface import ModelState
from vllm.v1.worker.gpu.sample.gumbel import gumbel_sample
from vllm.v1.worker.gpu.spec_decode.utils import draft_gumbel_pos
from vllm.v1.worker.utils import AttentionGroup

# Re-exported for the in-image draft-speculator family (dflash,
# multi_module_mtp) that types capture phases via this module.
CUDAGraphCapturePhase = Literal["profile", "production"]

logger = init_logger(__name__)


class BaseSpeculator(ABC):
    # [FORK-COMPAT] v84 draft-token capacity surface (v84 stock defaults,
    # verbatim from in-image spec_decode/speculator.py:41-46). The in-image
    # warmup chain (v1/worker/gpu/warmup.py warmup_kernels) reads these on
    # whichever speculator is mounted:
    #   ``wants_auto_sps_curve`` / ``warmup_capacity_kernels()`` after the
    #   verification-capacity manager warmup, ``set_sps_curve()`` from the
    #   dspark auto-SPS profiler. Only DSparkSpeculator (in-image, dspark/)
    #   overrides them; every other speculator must keep the stock defaults.
    # ``use_draft_token_capacity`` / ``online_sts`` are the same v84 surface
    # read by the v84 model_runner's capacity wiring.
    use_draft_token_capacity: bool = False
    online_sts: Any = None
    wants_auto_sps_curve: bool = False

    def warmup_capacity_kernels(self) -> None:  # noqa: B027
        pass

    def set_sps_curve(self, sps_curve: list[tuple[int, float]]) -> None:
        raise NotImplementedError

    def reset_attn(self) -> None:
        """Release objects derived from a target KV-cache allocation."""
        return None

    @abstractmethod
    def init_cudagraph_manager(self, cudagraph_mode: CUDAGraphMode) -> None:
        pass

    @abstractmethod
    def capture(self) -> None:
        pass

    @abstractmethod
    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        # [num_tokens, hidden_size]
        last_hidden_states: torch.Tensor,
        # num_layers x [num_tokens, hidden_size]
        aux_hidden_states: list[torch.Tensor] | None,
        # [num_reqs]
        num_sampled: torch.Tensor,
        # [num_reqs]
        num_rejected: torch.Tensor,
        # [max_num_reqs]
        last_sampled: torch.Tensor,
        # [num_prefill_lookahead, max_num_reqs]
        next_prefill_tokens: torch.Tensor,
        # [max_num_reqs]
        temperature: torch.Tensor,
        # [max_num_reqs]
        seeds: torch.Tensor,
        num_speculative_tokens: int | None = None,
        num_tokens_across_dp: torch.Tensor | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: bool = False,
    ) -> torch.Tensor:
        pass


class DraftModelSpeculator(BaseSpeculator):
    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        self.vllm_config = vllm_config
        self.device = device

        assert vllm_config.speculative_config is not None
        self.speculative_config = vllm_config.speculative_config
        self.method = self.speculative_config.method
        self.num_speculative_steps = self.speculative_config.num_speculative_tokens
        self.draft_model_config = self.speculative_config.draft_model_config

        self.scheduler_config = vllm_config.scheduler_config
        self.max_num_reqs = self.scheduler_config.max_num_seqs
        self.max_num_tokens = self.scheduler_config.max_num_batched_tokens
        self.max_model_len = vllm_config.model_config.max_model_len
        self.draft_max_seq_len = self.max_model_len
        # [FORK-COMPAT v84] DCP draft-prefill metadata rebuild: True when
        # decode context parallelism is on and any draft attention layer
        # sits in a dcp-replicated KV group (GLM-5.3-Flash MTP's kpool tail
        # under --decode-context-parallel-size 2). v84 recomputed draft
        # prefill slot mappings + attention metadata per propose() in that
        # case; upstream reuses the target's metadata unconditionally,
        # which is invalid for replicated-group boundary state.
        self.rebuild_prefill_attn_metadata = False
        # We need to get the hidden size from the draft model config because
        # the draft model's hidden size can be different from the target model's
        # hidden size (e.g., Llama 3.3 70B).
        self.hidden_size = self.draft_model_config.get_hidden_size()
        # Widen for HC-multiplexed residuals (e.g. DeepSeek V4 feeds the MTP
        # draft the target's pre-hc_head (T, hc_mult * hidden_size) residual).
        # Non-HC models default to hc_mult=1 and are unaffected.
        hc_mult = getattr(self.draft_model_config.hf_config, "hc_mult", 1)
        # GLM-5.3-Flash MTP drafts from the regular hidden state + token embed
        # (eh_proj: hidden*2 -> hidden), not the HC-multiplexed pre-hc_head
        # residual, so never widen for it regardless of mhc. Covers the target
        # (glm5_next) and MTP draft (glm5_next_mtp) config model_types.
        if getattr(self.draft_model_config.hf_config, "model_type", "").startswith(
            "glm5_next"
        ):
            hc_mult = 1
        self.hidden_size = self.hidden_size * hc_mult
        self.vocab_size = self.draft_model_config.get_vocab_size()
        self.dtype = vllm_config.model_config.dtype
        self.use_fp64_gumbel = vllm_config.model_config.use_fp64_gumbel
        self.use_local_argmax_reduction = (
            self.speculative_config.use_local_argmax_reduction
        )

        # DP configuration
        self.dp_size = vllm_config.parallel_config.data_parallel_size
        self.dp_rank = vllm_config.parallel_config.data_parallel_rank

        self.eplb_state: EplbState | None = None

        self.input_buffers = InputBuffers(
            max_num_reqs=self.max_num_reqs,
            max_num_tokens=self.max_num_tokens,
            device=device,
        )
        self.idx_mapping = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device=device
        )
        self.temperature = torch.zeros(
            self.max_num_reqs, dtype=torch.float32, device=device
        )
        self.seeds = torch.zeros(self.max_num_reqs, dtype=torch.int64, device=device)
        self.draft_tokens = torch.zeros(
            self.max_num_reqs,
            self.num_speculative_steps,
            dtype=torch.int64,
            device=device,
        )
        self.arange = torch.arange(
            self.max_num_reqs + 1, dtype=torch.int32, device="cpu"
        )

        self.draft_logits: torch.Tensor | None = None
        if self.speculative_config.draft_sample_method == "probabilistic":
            # Pre-temperature logits, cached from the previous decode step.
            dtype, fill = self.draft_logits_spec(vllm_config)
            self.draft_logits = torch.full(
                (
                    self.max_num_reqs,
                    self.num_speculative_steps,
                    self.vocab_size,
                ),
                fill,
                dtype=dtype,
                device=device,
            )

        self.supports_mm_inputs = False

    @abstractmethod
    def load_draft_model(
        self,
        target_model: nn.Module,
        target_attn_layer_names: set[str],
    ) -> nn.Module:
        pass

    def load_model(self, target_model: nn.Module) -> None:
        target_attn_layer_names = set(
            get_layers_from_vllm_config(
                self.vllm_config,
                AttentionLayerBase,  # type: ignore[type-abstract]
            ).keys()
        )

        self.model = self.load_draft_model(target_model, target_attn_layer_names)
        self._validate_local_argmax_reduction()

        all_attn_layers = set[str](
            get_layers_from_vllm_config(
                self.vllm_config,
                AttentionLayerBase,  # type: ignore[type-abstract]
            ).keys()
        )
        self.draft_attn_layer_names = all_attn_layers - target_attn_layer_names

        target_supports_mm = MULTIMODAL_REGISTRY.supports_multimodal_inputs(
            self.vllm_config.model_config
        )
        draft_supports_mm = supports_multimodal_embeddings(self.model)
        self.supports_mm_inputs = target_supports_mm and draft_supports_mm
        if target_supports_mm and not draft_supports_mm:
            logger.warning_once(
                "Draft model %s does not support external multimodal embeddings. "
                "Embeddings from the target model will not be passed to the "
                "drafter; using text-only draft inputs instead.",
                type(self.model).__name__,
            )

    def update_max_model_len(self, max_model_len: int) -> None:
        self.max_model_len = int(max_model_len)
        self.draft_max_seq_len = self.max_model_len
        update_model_len = getattr(self.model, "update_max_model_len", None)
        if update_model_len is not None:
            update_model_len(self.max_model_len)

    def set_eplb_state(self, eplb_state: EplbState) -> None:
        """Inject EPLB state after construction."""
        self.eplb_state = eplb_state

    def _prepare_eplb_forward(self, num_unpadded_tokens: int) -> None:
        """Call EPLB prepare_forward if EPLB is active for the draft model."""
        if self.eplb_state is not None:
            self.eplb_state.prepare_forward(
                self.speculative_config.draft_model_config,
                num_unpadded_tokens,
            )

    @property
    def attn_vllm_config(self) -> VllmConfig:
        """Config for the draft's attention metadata builders. Overridden by
        speculators whose attention mode differs from the target's."""
        return self.vllm_config

    def set_attn(
        self,
        model_state: ModelState,
        kv_cache_config: KVCacheConfig,
        block_tables: BlockTables,
        target_input_buffers: InputBuffers,
        target_attn_groups: list[list[AttentionGroup]],
    ) -> None:
        self.model_state = model_state
        self.kv_cache_config = kv_cache_config
        self.attn_groups, self.attn_cg_support, _ = init_attn_backend(
            kv_cache_config,
            self.attn_vllm_config,
            self.device,
            active_layer_names=self.draft_attn_layer_names,
        )
        self.block_tables = block_tables
        # The target model runner's buffers and attention groups. Draft
        # prefill reuses the target model's attention metadata, so its
        # cudagraph capture must build dummy metadata through the same
        # builders and buffers.
        self.target_input_buffers = target_input_buffers
        self.target_attn_groups = target_attn_groups
        # [FORK-COMPAT v84] Under decode context parallelism, a draft
        # attention layer in a dcp-replicated KV group cannot reuse the
        # target's prefill metadata/slot mappings: the replicated group's
        # boundary state is not token-sharded like the target's groups, so
        # propose() must recompute draft prefill attention state (v84
        # set_attn verbatim; upstream dropped it).
        self.rebuild_prefill_attn_metadata = block_tables.cp_size > 1 and any(
            getattr(group.kv_cache_spec, "dcp_replicated", False)
            and any(
                layer_name in self.draft_attn_layer_names
                for layer_name in group.layer_names
            )
            for group in kv_cache_config.kv_cache_groups
        )

    def reset_attn(self) -> None:
        """Release attention builders, tables, and graphs created by set_attn."""
        for name in (
            "model_state",
            "kv_cache_config",
            "attn_groups",
            "attn_cg_support",
            "block_tables",
            "target_attn_groups",
        ):
            if hasattr(self, name):
                delattr(self, name)
        for name in (
            "prefill_cudagraph_manager",
            "decode_cudagraph_manager",
            "cudagraph_manager",
            "query_cudagraph_manager",
        ):
            if hasattr(self, name):
                setattr(self, name, None)

    def _build_draft_attn_metadata(
        self,
        num_reqs: int,
        num_reqs_padded: int,
        num_tokens_padded: int,
        seq_lens_cpu_upper_bound: torch.Tensor,
        step: int,
        num_query_per_req: int = 1,
        causal: bool | Mapping[int, bool] = True,
        query_start_loc_np: np.ndarray | None = None,
        dcp_local_seq_lens: torch.Tensor | None = None,
    ) -> dict[str, Any] | None:
        if dcp_local_seq_lens is None and getattr(self.block_tables, "cp_size", 1) > 1:
            prepare_dcp_local_seq_lens(
                self.input_buffers.dcp_local_seq_lens,
                self.input_buffers.seq_lens,
                num_reqs,
                self.block_tables.cp_size,
                self.block_tables.cp_rank,
                self.block_tables.cp_interleave,
            )
            dcp_local_seq_lens = self.input_buffers.dcp_local_seq_lens
        if query_start_loc_np is not None:
            # Non-uniform query layout (e.g. multi-module MTP's mixed
            # prefill/decode queries); num_query_per_req is ignored.
            query_start_loc_cpu = torch.empty(num_reqs_padded + 1, dtype=torch.int32)
            query_start_loc_cpu[: num_reqs + 1] = torch.from_numpy(
                query_start_loc_np[: num_reqs + 1]
            )
            query_start_loc_cpu[num_reqs:] = query_start_loc_cpu[num_reqs]
            max_query_len = int(
                (query_start_loc_cpu[1:] - query_start_loc_cpu[:-1]).max()
            )
        else:
            # Uniform query: query_start_loc[i] = min(i, num_reqs) * num_query_per_req.
            # Clamp keeps the series non-decreasing past num_reqs, which some
            # attention backends require.
            query_start_loc_cpu = (
                torch.clamp(self.arange[: num_reqs_padded + 1], max=num_reqs)
                * num_query_per_req
            )
            max_query_len = num_query_per_req
        block_tables = [
            x[:num_reqs_padded] for x in self.block_tables.input_block_tables
        ]
        slot_mappings = self.block_tables.slot_mappings[:, :num_tokens_padded]
        draft_seq_lens_cpu_upper_bound = torch.zeros(
            num_reqs_padded, dtype=torch.int32, device="cpu"
        )
        torch.add(
            seq_lens_cpu_upper_bound[:num_reqs],
            step,
            out=draft_seq_lens_cpu_upper_bound[:num_reqs],
        )
        draft_seq_lens_cpu_upper_bound[:num_reqs].clamp_(max=self.max_model_len)
        # [FORK-COMPAT] upstream DefaultModelState provides
        # prepare_draft_attn_metadata; the in-image fork's model states
        # (interface/default/mamba_hybrid) do not — the only implementation is
        # the r7-pooled GLM5Next model state, which is not overlay-mounted.
        # Degrade to the stock default (no model-specific draft metadata)
        # when the bound model state lacks the hook instead of raising
        # AttributeError on the first MTP draft decode step.
        model_specific_attn_metadata = None
        prepare_draft_attn_metadata = getattr(
            self.model_state, "prepare_draft_attn_metadata", None
        )
        if prepare_draft_attn_metadata is not None:
            model_specific_attn_metadata = prepare_draft_attn_metadata(
                idx_mapping=self.idx_mapping,
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs_padded,
                draft_index=step,
            )
        seq_lens = self.input_buffers.seq_lens[:num_reqs_padded]
        # [DRAFT-INPUT RECOVERY] The speculator's persistent GPU buffers are
        # heap-adjacent small tensors and have been observed carrying stamped
        # values (block-id-scale runs / pointer-scale data) under concurrent
        # chunked prefill — the draft metadata build then computes grids from
        # garbage and enqueues the faulting kernels. Recover at the source:
        # clamp every seq_lens row into [1, draft_seq_len_upper_bound] — the
        # CPU upper bound is the design's own estimate, so the clamp is a
        # no-op for valid inputs and a safe floor for stamped ones.
        try:
            _bound = self.draft_max_seq_len
            _cpu_bound = int(draft_seq_lens_cpu_upper_bound[:num_reqs].max().item())
            _bound = max(
                1, min(_bound, _cpu_bound + self.num_speculative_steps + 1)
            )
            seq_lens = torch.clamp(seq_lens, min=1, max=_bound)
        except Exception:
            pass
        attn_metadata = build_attn_metadata(
            attn_groups=self.attn_groups,
            num_reqs=num_reqs_padded,
            num_tokens=num_tokens_padded,
            query_start_loc_gpu=self.input_buffers.query_start_loc[
                : num_reqs_padded + 1
            ],
            query_start_loc_cpu=query_start_loc_cpu,
            max_query_len=max_query_len,
            seq_lens=seq_lens,
            dcp_local_seq_lens=(
                None
                if dcp_local_seq_lens is None
                else dcp_local_seq_lens[:num_reqs_padded]
            ),
            max_seq_len=self.draft_max_seq_len,
            block_tables=block_tables,
            slot_mappings=slot_mappings,
            kv_cache_config=self.kv_cache_config,
            causal=causal,
            seq_lens_cpu_upper_bound=draft_seq_lens_cpu_upper_bound,
            model_specific_attn_metadata=model_specific_attn_metadata,
        )
        return attn_metadata

    def draft_logits_spec(self, vllm_config: VllmConfig) -> tuple[torch.dtype, float]:
        """Dtype and fill for the cached proposal distribution.

        Speculators that write only a subset of columns each step override this.
        """
        return vllm_config.model_config.head_dtype, 0.0

    def _validate_local_argmax_reduction(self) -> None:
        if not self.use_local_argmax_reduction:
            return
        if self.speculative_config.draft_sample_method == "probabilistic":
            raise ValueError(
                "use_local_argmax_reduction is not compatible with "
                "draft_sample_method='probabilistic'."
            )
        if not hasattr(self.model, "get_top_tokens"):
            raise ValueError(
                "use_local_argmax_reduction is enabled but draft model "
                f"{self.model.__class__.__name__} does not implement "
                "get_top_tokens()."
            )
        logger.info(
            "Using local argmax reduction for draft token generation "
            "(communication: O(2*tp_size) vs O(vocab_size))."
        )

    def _greedy_sample_draft(self, hidden_states: torch.Tensor) -> torch.Tensor:
        if self.use_local_argmax_reduction:
            return self.model.get_top_tokens(hidden_states)
        logits = self.model.compute_logits(hidden_states)
        return logits.argmax(dim=-1)

    def sample_draft(
        self,
        hidden_states: torch.Tensor,
        positions: torch.Tensor,
        idx_mapping: torch.Tensor,
        temperature: torch.Tensor,
        seeds: torch.Tensor,
        draft_step: torch.Tensor,
        draft_logits: torch.Tensor | None,
    ) -> torch.Tensor:
        if draft_logits is not None:
            logits = self.model.compute_logits(hidden_states)
            # [FORK-COMPAT] the in-image rejection kernel
            # (spec_decode/rejection_sampler_utils.py — not overlay-mounted)
            # keys BOTH its acceptance uniform and its recovery Gumbel noise
            # by the row's absolute position P. The v84 stock key
            # ``positions + 1`` collides with the recovery/acceptance stream
            # at offset P + 1 under the same per-request seed, correlating
            # the proposal draw with the acceptance/recovery draws and
            # biasing rejection sampling. The fork salts the draft stream
            # onto a disjoint Philox range (positions are bounded by
            # max_model_len, far below the 2**30 offset) — see in-image
            # spec_decode/utils.py draft_gumbel_pos, which the in-image
            # speculator family keys its drafts by.
            return gumbel_sample(
                logits,
                idx_mapping,
                temperature,
                seeds,
                draft_gumbel_pos(positions),
                apply_temperature=True,
                logits_cache=draft_logits,
                logits_cache_col=draft_step,
                use_fp64=self.use_fp64_gumbel,
            )
        return self._greedy_sample_draft(hidden_states)

    def _copy_request_inputs(
        self,
        num_reqs: int,
        # [num_reqs]
        idx_mapping: torch.Tensor,
        # [max_num_reqs]
        temperature: torch.Tensor,
        # [max_num_reqs]
        seeds: torch.Tensor,
    ) -> None:
        # Copy temperature, seeds, and idx mapping to the pre-allocated buffers.
        # NOTE(woosuk): For draft sampling, we only consider the temperature
        # and ignore the other sampling parameters such as top_k and top_p,
        # for simplicity and performance.
        # While this may slightly degrade the acceptance rate, it does not
        # affect the output distribution after rejection sampling.
        self.temperature.copy_(temperature)
        self.seeds.copy_(seeds)
        self.idx_mapping[:num_reqs].copy_(idx_mapping)
        # idx_mapping for CG padded requests points to -1, which is ignored
        # during sampling to prevent writing stale values to draft logits.
        self.idx_mapping[num_reqs:].fill_(-1)
